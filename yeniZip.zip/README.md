# Neta-Backend
Neta Backend for e-commerce and business web site

# Getting started 
   To get you started you can simply clone the repository
   
    - git clone https://github.com/dogukanc760/Neta-Backend
    
   and install the dependencies
    - npm install or yarn add 
    
    
 # Run the project 
 
  - npm start or yarn start 

# When you start the project, the relevant server settings and cloud, cloud database connections will start working automatically.
